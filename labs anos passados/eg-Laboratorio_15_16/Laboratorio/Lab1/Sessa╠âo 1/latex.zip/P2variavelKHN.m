

close all
clear all
clc

filename='dados.xlsx';
sheet=4;

%-Estes valores serve para tirar k a partir do T3 nas baixas frequencias

fk=xlsread(filename,sheet,'BP2');
xlRange = 'BP5:BP54';
x = xlsread(filename,sheet,xlRange);
xlRange = 'BR5:BR254';
y = xlsread(filename,sheet,xlRange);
ampk=(max(y)-min(y))/2;
xlRange = 'BQ5:BQ54';
x2 = xlsread(filename,sheet,xlRange);
ampk2=(max(x2)-min(x2))/2;

sheet=5
f2k=xlsread(filename,sheet,'A2');
xlRange = 'A5:A254';
x = xlsread(filename,sheet,xlRange);
xlRange = 'C5:C254';
y = xlsread(filename,sheet,xlRange);
amp2k=(max(y)-min(y))/2;
xlRange = 'B5:B254';
x2 = xlsread(filename,sheet,xlRange);
amp2k2=(max(x2)-min(x2))/2;


disp 'Podes tratar a info'

%%
%-Tratamento de T3 para estimar k

wk=(2*pi)*fk;
w2k=(2*pi)*f2k;
ampk_rel=ampk/ampk2;
amp2k_rel=amp2k/amp2k2;
ampk_div=20*log10(ampk_rel);
amp2k_div=20*log10(amp2k_rel);
k=10^(ampk_div/20)
k2=10^(amp2k_div/20)


disp 'Terminado!'

%%
%-Comportamento das caracteristicas variando k
P2vector=[10000 5000 2000 0];
Kvector=[1.0426 k k2 0];
Q=[1.2264 1.4349];

mil=1000;n=10^-9;
R1=51*mil;R2=100*mil;R3=10*mil;R4=R3;R5=R2;
R6=R3;R7=1000*mil;R8=R2;R9=R1;R10=R2;R11=R3;
P1=R2;C1=4.7*n;C2=C1;




P2_x=(0:5:10*1000);
for i=1:length(P2_x)
K_previsto(i)=P2_x(i)/R2*((P2_x(i)-10*mil)*(R2+R5))/(P2_x(i)*(P2_x(i)-10)-10*mil*R3);
end

plot(P2_x, K_previsto), hold on
plot(P2vector,Kvector,'ko')